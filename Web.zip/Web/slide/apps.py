from django.apps import AppConfig


class SlideConfig(AppConfig):
    name = 'slide'
